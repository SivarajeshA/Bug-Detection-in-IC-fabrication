import scala.collection.mutable.ListBuffer

object Circuit
{
    def checkEquivalenceOfCircuits(actualCircuit: Expr, givenCircuitEval: (Map[Variable, Boolean]) => Option[Boolean]): Boolean =
    {
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //  TODO - This function returns True if actualCircuit and the provided circuit are equivalent and      //
        //  false if they aren't.                                                                               //
        //  The parameter givenCircuitEval is a function which when passed an assignment to circuit variables   //
        //  returns the output of the provided circuit which you are trying to verify. It returns None if the   //
        //  circuit is unable to produce an output with the given assignment.                                   //
        //  The implementation provided below will not work for any of the test cases. You have to change this  //
        //  implementation.                                                                                     //
        //////////////////////////////////////////////////////////////////////////////////////////////////////////

        var select_no: Int = -1
        var memo = Map[Expr, Expr]()
        def AndtoMuxExpr(e: Expr): Expr = {
            //else {
                    e match {
                        case And(args) =>
                            select_no = select_no + 1
                            val selectVar = Variable("Sl"+select_no)
                            var li = ListBuffer[Expr]()
                            for (x <- args){
                              if (memo.contains(x)) {
                                  li += memo(x)
                              }
                              else {
                                var t = AndtoMuxExpr(x)
                                memo += (x->t)
                                li += t
                              }
                            }
                            Or(List(And(List(Or(li.toList), Not(selectVar))),
                              And(List(And(li.toList), selectVar))))

                        case Or(args) => {
                            var li = ListBuffer[Expr]()
                            for (x <- args)
                                li += AndtoMuxExpr(x)
                            Or(li.toList)
                        }
                        case Not(arg) => { Not(AndtoMuxExpr(arg))   }
                        case _ => e
                    }
           // }
        }
        val modExpr = AndtoMuxExpr(actualCircuit)
        val XORExpr = Or(List(And(List(actualCircuit,Not(modExpr))),And(List(Not(actualCircuit),modExpr))))
        val cnfResult = CNF.CNFConverter(XORExpr)
        var select_lit = ListBuffer[Literal]()
        val modelLit = cnfResult._2
        for(x<- 0 to select_no){
            select_lit += modelLit(Variable("Sl"+x))
        }
        var map = Map[Variable, Boolean]()
        val li = cnfResult._1
        val S = new Solver()
        for (x <- li.dropRight(1)) {
          S.addClause_(x)
        }

        for(x <- 0 to select_no){

            select_lit(x) = ~select_lit(x)
            if(S.solve(select_lit.toList ++ li.last)){
                val model = cnfResult._2
                for((k,v)<-model) {
                    map += (k -> S.modelValue(v))
                }
                if(Evaluation.evaluate(actualCircuit,map) != givenCircuitEval(map)){
                    return false
                }
                select_lit(x) = ~select_lit(x)
                map = Map.empty[Variable, Boolean]
            }
            else true
        }
        true
    }
}
