
object Main {

    def and(args: Expr*): Expr = And(args.toList)
    def or(args: Expr*): Expr = Or(args.toList)
    def not(arg: Expr): Expr = Not(arg)
    def var_(name: String) : Variable = Variable(name)
    def lit(value: Boolean): Expr = BoolLit(value)

    def testEquivalence = {
        def a = var_("a")
        def b = var_("b")
        def c = var_("c")
        def d = var_("d")

        val exp1 = and(a,b)
        val exp2 = not(or(not(a), not(b)))
        println("Execute 1")
        assert(Evaluation.areEquivalent(exp1, exp2) == true)
        println("Execute 2")
        assert(Evaluation.areEquivalent(exp1, not(exp2)) == false)

        val exp3 = and(a,b,c,d)
        val exp4 = and(and(a,b), and(c,d), lit(true))
        println("Execute 3")
        assert(Evaluation.areEquivalent(exp3, exp4) == true)
        println("Execute 4")
        assert(Evaluation.areEquivalent(exp3, not(exp4)) == false)

        var exp5 = and(or(a,b),and(c,not(d)))
        var exp6 = and(a,b,c,not(d))
        assert(Evaluation.areEquivalent(exp5, not(exp6)) == false)

         exp5 = a
         exp6 = a
        assert(Evaluation.areEquivalent(exp5, not(exp6)) == false)


        println("Finished")
    }
    
    def testSolver(): Unit = {
        println("============ test solver ============")
        val a = Literal.create(1)
        val b = Literal.create(2)
        val an = ~a
        val bn = ~b

        val S = new Solver()
        S.addClause(a, b)
        S.addClause(~a, ~b)
        // Solve
        println(S.solve())
        // Extract model.
        val va = S.modelValue(a)
        val vb = S.modelValue(b)
        println("model: [a -> %s, b -> %s]".format(va.toString(), vb.toString()))
    }

    def main(args: Array[String])
    {

        testSolver

         testEquivalence
        //Firewall.test1()
        CircuitTest.sampleTest
    }
}
