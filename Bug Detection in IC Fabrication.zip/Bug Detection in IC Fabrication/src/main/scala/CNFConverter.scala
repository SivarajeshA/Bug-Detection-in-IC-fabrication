import scala.collection.mutable.ListBuffer
import scala.collection.mutable.Map

object CNF {
  def CNFConverter(e: Expr): (ListBuffer[List[Literal]],Map[Variable, Literal]) = {
    var cacheVarLit = Map[Variable, Literal]()
    var memo = Map[Expr, Literal]()
    var li = new ListBuffer[List[Literal]]()
    var c: Int = 0;
    def actualCNF(e: Expr): Literal = {
      if (memo.contains (e) ) {
          memo(e)
      }
      else {
        e match {
           case v: Variable =>
            c += 1
            val litv = Literal.create(c)
            cacheVarLit += v -> litv
            memo += e -> litv
            return litv
           case And(args) =>
            c += 1
            val litAnd = Literal.create(c)
            val liA = args.map(x => actualCNF(x))
            var c1 = new ListBuffer[Literal]()
            c1 += litAnd
            for (x <- liA) {
              c1 += ~x
            }
            li += c1.toList
            for (x <- liA) {
              li += List(x, ~litAnd)
            }
            memo += e -> litAnd
            return litAnd

          case Or(args) =>
            c += 1
            val litOr = Literal.create(c)
            val liO = args.map(x => actualCNF(x))
            var c1 = new ListBuffer[Literal]()
            c1 += ~litOr
            for (x <- liO) {
              c1 += x
            }
            li += c1.toList
            for (x <- liO) {
              li += List(~x, litOr)
            }
            memo += e -> litOr
            return litOr

          case Not(a) =>
            c += 1
            val litNot = Literal.create(c)
            val liN = actualCNF(a)
            li += List(liN, litNot)
            li += List(~liN, ~litNot)
            memo += e -> litNot
            return litNot
        }
      }
    }
    li += List(actualCNF(e)) //Adding head node's literal
    return (li, cacheVarLit)
  }
}
